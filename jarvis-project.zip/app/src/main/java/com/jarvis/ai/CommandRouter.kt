package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/** Runs real Android actions. Used for quick local commands and for actions the AI plans. */
class CommandRouter(private val ctx: Context) {

    fun help(): String =
        "Abhi main ye samajhta hoon:\n" +
            "• \"open WhatsApp\" / \"YouTube kholo\"\n" +
            "• \"search science projects\"\n" +
            "• \"Bluetooth settings\", \"wifi\", \"settings\""

    /** Simple one-step commands handled without AI. Returns null if AI should handle it. */
    fun tryLocal(input: String): String? {
        val t = input.trim().lowercase()
        if (t.isEmpty()) return "Kuch likho, phir main karunga."
        val multi = listOf(" aur ", " and ", " phir ", " then ").any { it in t }
        if (multi) return null

        if (t == "settings" || t == "open settings" || t == "settings kholo") return run("open_settings", "main")
        if (t.endsWith("bluetooth settings") || t == "bluetooth") return run("open_settings", "bluetooth")
        if (t == "wifi" || t == "wi-fi" || t == "wifi settings") return run("open_settings", "wifi")

        val query = when {
            t.startsWith("search ") -> t.removePrefix("search ").removePrefix("for ")
            t.endsWith(" search karo") -> t.removeSuffix(" search karo")
            else -> null
        }
        if (!query.isNullOrBlank() && query.split(" ").size <= 6) return run("search_web", query)

        val skip = setOf("open", "kholo", "khol", "do", "karo", "please", "app", "the", "my", "mujhe")
        val name = t.split(" ").filter { it !in skip }.joinToString(" ").trim()
        if ((t.startsWith("open ") || t.endsWith(" kholo") || t.startsWith("kholo ")) &&
            name.isNotEmpty() && name.split(" ").size <= 3
        ) return openApp(name)

        return null
    }

    /** Executes one action planned by the AI. */
    fun run(a: AiAction): String = when (a.type) {
        "open_app" -> openApp(a.args.optString("name").lowercase().trim())
        "search_web" -> run("search_web", a.args.optString("query"))
        "youtube_search" -> youtubeSearch(a.args.optString("query"))
        "open_settings" -> run("open_settings", a.args.optString("page"))
        "dial" -> dial(a.args.optString("number"))
        else -> "Ye action abhi supported nahi hai: ${a.type}"
    }

    private fun run(type: String, arg: String): String = when (type) {
        "search_web" -> {
            val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(arg.trim()))
            start(Intent(Intent.ACTION_VIEW, uri), "Search: ${arg.trim()}")
        }
        else -> {
            val action = when (arg.lowercase()) {
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            start(Intent(action), "Settings khol di (${arg.ifBlank { "main" }}).")
        }
    }

    private fun youtubeSearch(query: String): String {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query.trim()))
        val withApp = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube")
        return try {
            withApp.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(withApp)
            "YouTube par search: ${query.trim()}"
        } catch (e: Exception) {
            start(Intent(Intent.ACTION_VIEW, uri), "YouTube search (browser mein): ${query.trim()}")
        }
    }

    private fun dial(number: String): String {
        if (number.isBlank()) return "Number nahi mila."
        return start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))), "Dialer khola: $number (call aap khud dabaoge).")
    }

    private fun openApp(name: String): String {
        if (name.isBlank()) return "App ka naam nahi mila."
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .firstOrNull { it.second.lowercase().contains(name) }
            ?: return "\"$name\" naam ka app nahi mila."
        val launch = pm.getLaunchIntentForPackage(match.first)
            ?: return "${match.second} ko khol nahi paya."
        return start(launch, "${match.second} khol raha hoon.")
    }

    private fun start(intent: Intent, ok: String): String =
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            ok
        } catch (e: Exception) {
            "Ye kaam nahi ho paya: ${e.message}"
        }
}
