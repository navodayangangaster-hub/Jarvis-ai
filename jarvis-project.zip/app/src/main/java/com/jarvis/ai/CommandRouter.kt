package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/** Turns typed text into real Android actions. Phase 1: local commands only. */
class CommandRouter(private val ctx: Context) {

    fun handle(input: String): String {
        val t = input.trim().lowercase()
        if (t.isEmpty()) return "Kuch likho, phir main karunga."

        if ("bluetooth" in t) return start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Bluetooth settings khol di.")
        if ("wifi" in t || "wi-fi" in t) return start(Intent(Settings.ACTION_WIFI_SETTINGS), "Wi-Fi settings khol di.")
        if (t == "settings" || t == "open settings" || t == "settings kholo")
            return start(Intent(Settings.ACTION_SETTINGS), "Settings khol di.")

        val query = when {
            t.startsWith("search ") -> t.removePrefix("search ").removePrefix("for ")
            t.endsWith(" search karo") -> t.removeSuffix(" search karo")
            t.startsWith("google ") -> t.removePrefix("google ")
            else -> null
        }
        if (!query.isNullOrBlank()) {
            val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query.trim()))
            return start(Intent(Intent.ACTION_VIEW, uri), "Search kar raha hoon: ${query.trim()}")
        }

        val openWords = setOf("open", "kholo", "khol", "do", "karo", "please", "app", "the", "my", "mujhe")
        val name = t.split(" ").filter { it !in openWords }.joinToString(" ").trim()
        if ((t.startsWith("open ") || t.endsWith(" kholo") || t.startsWith("kholo ")) && name.isNotEmpty())
            return openApp(name)

        return "Abhi main sirf ye samajhta hoon:\n" +
            "• \"open WhatsApp\" / \"YouTube kholo\"\n" +
            "• \"search science projects\"\n" +
            "• \"Bluetooth settings\", \"wifi\", \"settings\"\n" +
            "AI jawab Phase 2 mein judenge."
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .firstOrNull { it.second.lowercase().contains(name) }
            ?: return "\"$name\" naam ka app nahi mila."
        val launch = pm.getLaunchIntentForPackage(match.first)
            ?: return "${match.second} ko khol nahi paya."
        return start(launch, "${match.second} khol raha hoon.")
    }

    private fun start(intent: Intent, ok: String): String =
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            ok
        } catch (e: Exception) {
            "Ye kaam nahi ho paya: ${e.message}"
        }
}
