package com.jarvis.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AiAction(val type: String, val args: JSONObject)
data class AiResult(val reply: String, val actions: List<AiAction>)

/** Talks to YOUR backend (Cloudflare Worker). The AI key never lives in the app. */
object AiClient {
    fun ask(url: String, token: String, history: List<Msg>): AiResult {
        val msgs = JSONArray()
        history.takeLast(12).forEach {
            msgs.put(
                JSONObject()
                    .put("role", if (it.fromUser) "user" else "assistant")
                    .put("content", it.text)
            )
        }
        val body = JSONObject().put("messages", msgs).toString()

        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 40000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("X-App-Token", token)
        }
        try {
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.readText() ?: ""
            if (code == 401) throw IllegalStateException("Token galat hai. Settings (⚙) check karo.")
            if (code !in 200..299) throw IllegalStateException("Backend error $code: ${text.take(150)}")

            val json = JSONObject(text)
            val reply = json.optString("reply", "")
            val list = ArrayList<AiAction>()
            val arr = json.optJSONArray("actions")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    list.add(AiAction(o.optString("type"), o))
                }
            }
            return AiResult(reply.ifBlank { "Theek hai." }, list)
        } finally {
            conn.disconnect()
        }
    }
}
