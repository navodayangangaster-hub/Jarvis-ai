package com.jarvis.ai

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Msg(val fromUser: Boolean, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val router = CommandRouter(this)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF0A0E1A))) {
                JarvisScreen(router, prefs)
            }
        }
    }
}

@Composable
fun JarvisScreen(router: CommandRouter, prefs: SharedPreferences) {
    val messages = remember {
        mutableStateListOf(Msg(false, "Namaste! Main Jarvis hoon. Mujhse kuch bhi poochho ya bolo \"YouTube par science experiment search karo\". Pehle ⚙ mein backend URL aur token daalna.")
        )
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        messages.add(Msg(true, text))
        input = ""
        val url = prefs.getString("url", "") ?: ""
        val token = prefs.getString("token", "") ?: ""
        job = scope.launch {
            busy = true
            try {
                val local = router.tryLocal(text)
                if (local != null) {
                    messages.add(Msg(false, local))
                } else if (url.isBlank() || token.isBlank()) {
                    messages.add(Msg(false, router.help() + "\n\nAI jawab ke liye ⚙ mein backend URL aur token daalo."))
                } else {
                    val history = messages.drop(1).toList()
                    val result = withContext(Dispatchers.IO) { AiClient.ask(url, token, history) }
                    messages.add(Msg(false, result.reply))
                    for (a in result.actions) {
                        delay(1500)
                        messages.add(Msg(false, "▶ " + router.run(a)))
                    }
                }
            } catch (e: CancellationException) {
                messages.add(Msg(false, "Roka gaya."))
                throw e
            } catch (e: Exception) {
                messages.add(Msg(false, "Error: ${e.message}"))
            } finally {
                busy = false
            }
        }
    }

    LaunchedEffect(messages.size) { listState.animateScrollToItem(messages.size - 1) }

    if (showSettings) {
        var u by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
        var k by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("AI Backend") },
            text = {
                Column {
                    OutlinedTextField(u, { u = it }, label = { Text("Backend URL") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(k, { k = it }, label = { Text("App token") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    prefs.edit().putString("url", u.trim()).putString("token", k.trim()).apply()
                    showSettings = false
                    messages.add(Msg(false, "Settings save ho gayi."))
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF0A0E1A)).statusBarsPadding().navigationBarsPadding().imePadding().padding(12.dp)
    ) {
        Box(Modifier.fillMaxWidth()) {
            Orb(Modifier.align(Alignment.Center))
            TextButton(onClick = { showSettings = true }, modifier = Modifier.align(Alignment.TopEnd)) { Text("⚙ Settings") }
        }
        if (busy) Text("Soch raha hoon...", Modifier.align(Alignment.CenterHorizontally), color = Color(0xFF9BF0FF))
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (m.fromUser) Color(0xFF1E5EFF) else Color(0xFF161C2E)
                    ) { Text(m.text, Modifier.padding(12.dp), color = Color.White) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Command likho...") },
                singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            if (busy) {
                Button(
                    onClick = { job?.cancel() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                ) { Text("Stop") }
            } else {
                Button(onClick = { send() }) { Text("Send") }
            }
        }
    }
}

@Composable
fun Orb(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        0.85f, 1.1f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    Canvas(modifier.size(140.dp)) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2 * 0.7f * pulse
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF6FE7FF), Color(0xFF1E5EFF), Color.Transparent), c, r * 1.4f),
            r * 1.4f, c
        )
        drawCircle(Color(0xFF9BF0FF), r * 0.45f, c, alpha = 0.9f)
    }
}
