package com.jarvis.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

data class Msg(val fromUser: Boolean, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val router = CommandRouter(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF0A0E1A))) {
                JarvisScreen(router)
            }
        }
    }
}

@Composable
fun JarvisScreen(router: CommandRouter) {
    val messages = remember { mutableStateListOf(Msg(false, "Namaste! Main Jarvis hoon. Try karo: \"open YouTube\" ya \"search science projects\".")) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    fun send() {
        val text = input.trim()
        if (text.isEmpty()) return
        messages.add(Msg(true, text))
        input = ""
        messages.add(Msg(false, router.handle(text)))
    }

    LaunchedEffect(messages.size) { listState.animateScrollToItem(messages.size - 1) }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF0A0E1A)).statusBarsPadding().navigationBarsPadding().imePadding().padding(12.dp)
    ) {
        Orb(Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (m.fromUser) Color(0xFF1E5EFF) else Color(0xFF161C2E)
                    ) { Text(m.text, Modifier.padding(12.dp), color = Color.White) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Command likho...") },
                singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }) { Text("Send") }
        }
    }
}

@Composable
fun Orb(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        0.85f, 1.1f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    Canvas(modifier.size(140.dp)) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2 * 0.7f * pulse
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF6FE7FF), Color(0xFF1E5EFF), Color.Transparent), c, r * 1.4f),
            r * 1.4f, c
        )
        drawCircle(Color(0xFF9BF0FF), r * 0.45f, c, alpha = 0.9f)
    }
}
